package seltest;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.junit.Assert.*;

import org.junit.Test;


public class registertest {
	public static void main(String[] args){
		Emailgeneratorv2 gen = new Emailgeneratorv2();
		String firstName = "John";
		String lastName = "Doe";
		Boolean success = false;
		
		WebDriver driver = new ChromeDriver();
		//direct to qa5
		driver.get("https://qa5.caringbridge.org/");
		
		WebElement element = driver.findElement(By.xpath("//a[@data-qa-id='global-nav-login']"));
		//wait until we can find the element
		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@data-qa-id='global-nav-login']")));
		//click redirects us to next register page
		element.click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@data-qa-id='profile-signin-signup']")));
		//click redirects us to register page
		driver.findElement(By.xpath("//a[@data-qa-id='profile-signin-signup']")).click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@data-qa-id='profile-signup-first-name']")));
		//input first name
		driver.findElement(By.xpath("//input[@data-qa-id='profile-signup-first-name']")).sendKeys(firstName);;
		//input last name
		driver.findElement(By.xpath("//input[@data-qa-id='profile-signup-last-name']")).sendKeys(lastName);
		
		//generate an email string
		String email = gen.emailgen();
		//print out the email string
		System.out.println(email);
		//register with email
		driver.findElement(By.xpath("//input[@data-qa-id='profile-signup-email']")).sendKeys(email);
		//input password
		driver.findElement(By.xpath("//input[@data-qa-id='profile-signup-password']")).sendKeys("abc123");
		//click on terms of agreement
		driver.findElement(By.xpath("//input[@data-qa-id='profile-signup-terms']")).click();
		//click on register
		driver.findElement(By.xpath("//input[@data-qa-id='profile-signup-submit']")).click();
		
		//check if the sign in (aka not logged in) button is there.
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@data-qa-id='global-nav-home']")));
		if(driver.findElements(By.xpath("//a[@href='https://qa5.caringbridge.org/signin?returl=%2F']")).size() != 0){
			driver.quit();
		}
		//heading to profile
		driver.findElement(By.xpath("//a[@data-qa-id='global-nav-home']")).click();
		//verifying that the registration process completed successful
		driver.get("https://qa5.caringbridge.org/settings");
		
		//checking firstName
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='firstName']")));
		element = driver.findElement(By.xpath("//input[@id='firstName']"));
		if(firstName.equals(element.getAttribute("value"))){
			success = true;
		}else{
			fail("First Name different from the one entered.");
		}
		//checking last name
		element = driver.findElement(By.xpath("//input[@id='lastName']"));
		if(lastName.equals(element.getAttribute("value"))){
		}else{
			fail("Last Name different from the one entered.");
		}
		//checking email
		element = driver.findElement(By.xpath("//input[@id='email']"));
		if(email.equals(element.getAttribute("value"))){
		}else{
			fail("Email different from the one entered.");
		}
		driver.quit();
	}

}
